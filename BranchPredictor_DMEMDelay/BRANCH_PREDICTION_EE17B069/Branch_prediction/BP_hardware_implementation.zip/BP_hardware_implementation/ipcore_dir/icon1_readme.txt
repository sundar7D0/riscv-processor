The following files were generated for 'icon1' in directory
/home/pruthvirg/Desktop/sem_fire/comp_org/wd_assign_4/synthesis_versions/final_branch_prediction/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * icon1.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * icon1.constraints/icon1.ucf
   * icon1.constraints/icon1.xdc
   * icon1.ngc
   * icon1.ucf
   * icon1.v
   * icon1.veo
   * icon1.xdc
   * icon1_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * icon1.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * icon1.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * icon1.gise
   * icon1.xise

Deliver Readme:
   Readme file for the IP.

   * icon1_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * icon1_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

