The following files were generated for 'vio1' in directory
/home/pruthvirg/Desktop/sem_fire/comp_org/wd_assign_4/synthesis_versions/final_branch_prediction/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * vio1.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * vio1.cdc
   * vio1.constraints/vio1.ucf
   * vio1.constraints/vio1.xdc
   * vio1.ngc
   * vio1.ucf
   * vio1.v
   * vio1.veo
   * vio1.xdc
   * vio1_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * vio1.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * vio1.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * vio1.gise
   * vio1.xise

Deliver Readme:
   Readme file for the IP.

   * vio1_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * vio1_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

